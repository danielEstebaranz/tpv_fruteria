import 'package:tpv_fruteria/venta.dart';

List<Venta> ventas=[];