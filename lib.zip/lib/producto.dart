class Producto {
  String nombre;
  double precio;
  String imagen;
  String tipo;

  Producto({required this.nombre, required this.precio, required this.imagen, required this.tipo});
}