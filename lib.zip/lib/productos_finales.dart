import 'package:tpv_fruteria/producto.dart';

List <Producto> productos = [
  Producto(
    nombre: 'Manzana',
    precio: 1.50,
    imagen: 'assets/images/manzana.jpeg',
    tipo: 'fruta',
  ),
  Producto(
    nombre: 'Plátano',
    precio: 1.20,
    imagen: 'assets/images/platano.jpg',
    tipo: 'fruta',
  ),
  Producto(
    nombre: 'Naranja',
    precio: 1.10,
    imagen: 'assets/images/naranja.jpg',
    tipo: 'fruta',
  ),
  Producto(
    nombre: 'Lechuga',
    precio: 0.95,
    imagen: 'assets/images/lechuga.jpg',
    tipo: 'verdura',
  ),
  Producto(
    nombre: 'Tomate',
    precio: 1.30,
    imagen: 'assets/images/tomate.jpeg',
    tipo: 'verdura',
  ),
];